
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import re

from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import sqlite3, jwt, datetime, os, smtplib
from email.mime.text import MIMEText
from itsdangerous import URLSafeTimedSerializer

app = Flask(__name__)

TEMPLATES_DB = "templates.json"

def load_templates():
    try:
        with open(TEMPLATES_DB, "r") as f:
            return json.load(f)
    except:
        return {}

def save_templates(data):
    with open(TEMPLATES_DB, "w") as f:
        json.dump(data, f, indent=2)


import json

USAGE_DB = "users_usage.json"

def load_usage():
    try:
        with open(USAGE_DB, "r") as f:
            return json.load(f)
    except:
        return {}

def save_usage(data):
    with open(USAGE_DB, "w") as f:
        json.dump(data, f, indent=2)

def increment_usage(user_id, prompt):
    usage = load_usage()
    user = usage.get(user_id, {"email_count": 0, "recent_prompts": []})
    user["email_count"] += 1
    user["recent_prompts"] = [prompt] + user["recent_prompts"][:4]
    usage[user_id] = user
    save_usage(usage)


# Setup rate limiting
limiter = Limiter(get_remote_address, app=app, default_limits=["10 per minute"])

app.secret_key = "supersecretkey"
serializer = URLSafeTimedSerializer(app.secret_key)

DATABASE = os.path.join(os.path.dirname(__file__), '..', 'app.db')

def send_verification_email(user_email):
    token = serializer.dumps(user_email, salt='email-confirm')
    link = f"http://localhost:5000/verify?token={token}"
    msg = MIMEText(f"Welcome to IntroIQ! Click to verify your email: {link}")
    msg['Subject'] = 'Verify your IntroIQ Email'
    msg['From'] = 'no-reply@introiq.com'
    msg['To'] = user_email

    try:
        s = smtplib.SMTP('localhost')
        s.sendmail(msg['From'], [msg['To']], msg.as_string())
        s.quit()
    except Exception as e:
        print("Email error:", e)

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


from flask import Flask, request, jsonify
from flask_cors import CORS
import jwt
import datetime
import logging
import os

app = Flask(__name__)

TEMPLATES_DB = "templates.json"

def load_templates():
    try:
        with open(TEMPLATES_DB, "r") as f:
            return json.load(f)
    except:
        return {}

def save_templates(data):
    with open(TEMPLATES_DB, "w") as f:
        json.dump(data, f, indent=2)


import json

USAGE_DB = "users_usage.json"

def load_usage():
    try:
        with open(USAGE_DB, "r") as f:
            return json.load(f)
    except:
        return {}

def save_usage(data):
    with open(USAGE_DB, "w") as f:
        json.dump(data, f, indent=2)

def increment_usage(user_id, prompt):
    usage = load_usage()
    user = usage.get(user_id, {"email_count": 0, "recent_prompts": []})
    user["email_count"] += 1
    user["recent_prompts"] = [prompt] + user["recent_prompts"][:4]
    usage[user_id] = user
    save_usage(usage)


# Setup rate limiting
limiter = Limiter(get_remote_address, app=app, default_limits=["10 per minute"])

CORS(app)
app.config['SECRET_KEY'] = 'your-secret-key'

# Logging
logging.basicConfig(level=logging.INFO)

# Rate limit placeholder
rate_limit_counter = {}

# Mock user store
users = {"test@example.com": "password"}

# Dummy in-memory prompts
saved_prompts = []

@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    if email in users:
        return jsonify({'message': 'User already exists'}), 400
    users[email] = password
    return jsonify({'message': 'User created successfully'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    if users.get(email) != password:
        return jsonify({'message': 'Invalid credentials'}), 401
    token = jwt.encode({
        'email': email,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }, app.config['SECRET_KEY'], algorithm='HS256')
    return jsonify({'token': token})

@app.route('/save_prompt', methods=['POST'])
def save_prompt():
    data = request.json
    prompt_raw = data.get("prompt", "")
    prompt = re.sub(r"[<>]", "", prompt_raw.strip())
    
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith("Bearer "):
        return jsonify({"error": "Unauthorized"}), 401
    token = auth_header.split(" ")[1]
    try:
        decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        email = decoded.get('email')
    except:
        return jsonify({"error": "Invalid token"}), 401
    saved_prompts.append({'email': email, 'prompt': prompt})
        
    logging.info(f"Prompt saved: {prompt}")
    return jsonify({'message': 'Prompt saved'})

@app.route('/generate', methods=['POST'])
def generate_email():
    prompt = request.json.get('prompt')
    if not prompt:
        return jsonify({'error': 'No prompt provided'}), 400
    # Mock OpenAI response
    email_text = f"Hi there,

Based on your request: '{prompt}', here's your cold email.

Best,
AI Assistant"
    return jsonify({'email': email_text})

@app.route('/checkout', methods=['POST'])
def stripe_checkout():
    return jsonify({'checkout_url': 'https://stripe.com/checkout-session-mock'})

@app.route('/webhook/razorpay', methods=['POST'])
def razorpay_webhook():
    data = request.json
    logging.info(f"Razorpay webhook received: {data}")
    return jsonify({'status': 'received'})


@app.route('/my_prompts', methods=['GET'])
def my_prompts():
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith("Bearer "):
        return jsonify({"error": "Unauthorized"}), 401
    token = auth_header.split(" ")[1]
    try:
        decoded = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        email = decoded.get('email')
        user_prompts = [p for p in saved_prompts if p.get('email') == email]
        return jsonify({'prompts': user_prompts})
    except Exception as e:
        return jsonify({"error": "Invalid token"}), 401


if __name__ == '__main__':
    app.run(debug=True)


@app.route('/verify')
def verify_email():
    token = request.args.get('token')
    try:
        email = serializer.loads(token, salt='email-confirm', max_age=3600)
        conn = get_db()
        conn.execute("UPDATE users SET is_verified = 1 WHERE email = ?", (email,))
        conn.commit()
        return "✅ Email verified! You can now log in."
    except Exception as e:
        return "❌ Verification link is invalid or expired."

@app.route('/generate', methods=['POST'])
def generate():
    user_id = get_jwt_identity()
    sub = get_user_subscription_status(user_id)
    if sub == 'free':
        from datetime import datetime
        today = datetime.now().strftime('%Y-%m-%d')
        user_day_key = f"{user_id}_{today}"
        prompt_count = prompt_logs.get(user_day_key, 0)
        if prompt_count >= FREE_TIER_LIMIT:
            return jsonify({"error": "Prompt limit reached for free plan. Please upgrade."}), 403
        prompt_logs[user_day_key] = prompt_count + 1

    token = request.headers.get('Authorization')
    if not token:
        return jsonify({"error": "Unauthorized"}), 401
    try:
        payload = jwt.decode(token, app.secret_key, algorithms=["HS256"])
    except:
        return jsonify({"error": "Invalid token"}), 403

    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (payload['user_id'],)).fetchone()
    if not user['is_verified']:
        return jsonify({"error": "Please verify your email before using the app."}), 403

    data = request.get_json()
    prompt = data['prompt']

    import openai
    openai.api_key = os.environ.get("OPENAI_API_KEY")
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Write a cold email: {prompt}",
        max_tokens=150
    )
    result = response.choices[0].text.strip()

    conn.execute("INSERT INTO prompt_logs (user_id, prompt, generated_email, timestamp) VALUES (?, ?, ?, ?)",
                 (user['id'], prompt, result, datetime.datetime.utcnow().isoformat()))
    conn.commit()

    return jsonify({"response": result})


import stripe
import uuid
stripe.api_key = "sk_test_51NXXX_YOUR_TEST_KEY_HERE"

@app.route("/stripe/subscribe", methods=["GET"])
@jwt_required()
def stripe_subscribe():
    user_id = get_jwt_identity()
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            "price": "price_1PXXX_YOUR_TEST_PRICE_ID",  # Replace with your Stripe test price
            "quantity": 1,
        }],
        mode="subscription",
        success_url="http://localhost:5000/success?session_id={CHECKOUT_SESSION_ID}",
        cancel_url="http://localhost:5000/static/dashboard.html",
        client_reference_id=user_id,
    )
    return redirect(session.url, code=303)


@app.route("/razorpay/subscribe", methods=["GET"])
@jwt_required()
def razorpay_subscribe():
    # Simulated Razorpay hosted subscription link (test version)
    return redirect("https://rzp.io/l/YOUR_TEST_RAZORPAY_SUBSCRIPTION")


@app.route("/webhook/payment", methods=["POST"])
def payment_webhook():
    # Simulated webhook – In real deployment, verify and mark user as 'pro'
    return jsonify({"status": "received"}), 200


@app.route('/success')
def success():
    return redirect('/static/success.html')


@app.route("/admin/promote", methods=["POST"])
def promote_user():
    data = request.get_json()
    username = data.get("username")
    if not username:
        return jsonify({"error": "Username required"}), 400

    users = load_users()
    if username not in users:
        return jsonify({"error": "User not found"}), 404

    users[username]["subscription"] = "pro"
    save_users(users)
    return jsonify({"message": f"{username} promoted to pro."})


from functools import wraps
from flask import Response

def check_admin_auth(username, password):
    return username == "admin" and password == "secret123"

def require_admin_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_admin_auth(auth.username, auth.password):
            return Response(
                'Could not verify access to admin panel', 401,
                {'WWW-Authenticate': 'Basic realm="Login Required"'}
            )
        return f(*args, **kwargs)
    return decorated

@app.route('/static/admin.html')
@require_admin_auth
def protected_admin():
    return redirect('/admin-protected')


@app.route('/admin-protected')
def admin_page():
    return app.send_static_file("admin.html")


import os
import requests
from dotenv import load_dotenv
load_dotenv()

SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY", "YOUR_SENDGRID_KEY")

@app.route('/send-email', methods=['POST'])
@require_auth
def send_email():
    data = request.get_json()
    to_email = data.get("to")
    subject = data.get("subject")
    body = data.get("body")
    from_email = data.get("from", "noreply@introiq.com")

    if not to_email or not subject or not body:
        return jsonify({"error": "Missing required fields"}), 400

    payload = {
        "personalizations": [{ "to": [{ "email": to_email }] }],
        "from": { "email": from_email },
        "subject": subject,
        "content": [{ "type": "text/plain", "value": body }]
    }

    response = requests.post(
        "https://api.sendgrid.com/v3/mail/send",
        headers={
            "Authorization": f"Bearer {SENDGRID_API_KEY}",
            "Content-Type": "application/json"
        },
        json=payload
    )

    if response.status_code >= 200 and response.status_code < 300:
        return jsonify({"message": "Email sent successfully!"})
    else:
        return jsonify({"error": "Failed to send email", "details": response.text}), 500

@app.route("/usage", methods=["GET"])
@require_auth
def get_usage():
    usage = load_usage()
    user_data = usage.get(request.user_id, {"email_count": 0, "recent_prompts": []})
    return jsonify(user_data)

@app.route("/save-template", methods=["POST"])
@require_auth
def save_template():
    data = request.json
    title = data.get("title", "Untitled")
    body = data.get("body", "").strip()

    if not body:
        return jsonify({"error": "Template body required"}), 400

    db = load_templates()
    templates = db.get(request.user_id, [])
    templates.insert(0, {"title": title, "body": body})
    db[request.user_id] = templates[:10]
    save_templates(db)
    return jsonify({"success": True})

@app.route("/my-templates", methods=["GET"])
@require_auth
def get_templates():
    db = load_templates()
    return jsonify(db.get(request.user_id, []))

@app.route("/linkedin-personalize", methods=["POST"])
@require_auth
def linkedin_personalize():
    data = request.json
    url = data.get("url", "").strip()

    if not url.startswith("http"):
        return jsonify({"error": "Invalid URL"}), 400

    # Simulated scraped data
    fake_profile = {
        "name": "Sarah",
        "role": "Head of Growth",
        "company": "Zapier",
        "interests": "automation tools, remote work, productivity"
    }

    prompt = f"Write a friendly cold email for a lead named {fake_profile['name']}, who is {fake_profile['role']} at {fake_profile['company']}. Mention their interest in {fake_profile['interests']}."

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        message = response["choices"][0]["message"]["content"]
        return jsonify({ "personalized_email": message })
    except Exception as e:
        return jsonify({"error": str(e)}), 500