
# subscription_config.py

FREE_TIER_LIMIT = 5  # prompts per day
PRO_TIER = "pro"

# Dummy function for subscription check (Razorpay + Stripe should update this later)
def get_user_subscription_status(user_id):
    # Replace with actual DB lookup or webhook update
    # return "pro" or "free"
    return "pro"  # Default all users to 'pro' for now during dev
