
# IntroIQ - AI Cold Email Assistant

This is the full source code for IntroIQ, a Flask-based SaaS that helps users write AI-personalized cold emails, save prompts, send via SendGrid, and manage Pro subscriptions.

## Features

- OpenAI-powered cold email generator
- Prompt saving and email templates
- JWT-based login and signup
- Admin panel with user stats
- SendGrid email sending
- Stripe/Razorpay (test mode)
- Replit + Render deployable

## Deploy Instructions

1. Copy `.env.example` to `.env` and fill in API keys
2. Run `pip install -r requirements.txt`
3. Run `flask run` or `python app.py`

## Deploy to Render

Includes `render.yaml` for 1-click deployment.

---

© 2025 IntroIQ. Built with ❤️ using Flask.
